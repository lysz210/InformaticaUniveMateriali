/* Query per l'esercizio 6.5 (leggermente modificate rispetto alla versione presente nel libro di testo per adattarle ai dati inseriti nell'esempio). Le soluzioni di alcune query potranno essere verificate scaricando il file delle soluzioni del capitolo 6 sul sito di supporto al libro */

(a) Trovare il nome e l’anno di nascita dei figli dell’impiegato con codice 122.(b) Trovare il nome e codice degli impiegati e il nome del dipartimento dove lavorano.(c) Trovare il nome degli impiegati, il nome e l’anno di nascita dei figli maschi a carico.(d) Trovare, per ogni progetto in corso a Pisa, il numero e il nome del progetto, il nome del dipartimento dove si svolge, il cognome del direttore del dipartimento.(e) Trovare il nome dei dipartimenti con almeno un impiegato con persone a carico.(f) Trovare il numero degli impiegati dei dipartimenti di Informatica.(g) Trovare, per ogni progetto al quale lavorano piu` di due impiegati, il nome, il numero e il numero degli impiegati che vi lavorano.(h) Trovare per ogni dipartimento il nome, il numero degli impiegati e la media del loro anno di nascita.(i) Trovare i nomi dei supervisori e dei loro dipendenti.(j) Trovare il nome degli impiegati e il nome del dipartimento in cui lavorano.(k) Trovare il nome degli impiegati senza familiari a carico.(l) Trovare i progetti cui partecipa il sig. Pablo Rossi come impiegato o come direttore del dipartimento che gestisce il progetto.(m) Trovare il nome degli impiegati che hanno i familiari a carico dello stesso sesso.(n) Trovare il nome degli impiegati che hanno tutti i familiari a carico del proprio stesso sesso.(o) Trovare il nome degli impiegati che lavorano almeno a tutti i progetti dell’impiegato con codice 169.(p) Trovare il numero e il nome del dipartimento e il numero di impiegati nati dopo il 1986, per i dipartimenti con piu` di due impiegati.

*/

CREATE DATABASE Azienda IN BDAzienda;

CREATE TABLE Dipartimenti
(  Numero INTEGER NOT NULL,
   Nome VARCHAR(20) NOT NULL,
   Citta VARCHAR(10) NOT NULL,

PRIMARY KEY P_Dipartimenti (Numero),
UNIQUE(Nome,Citta) )
;

CREATE TABLE Impiegati
(  Codice INTEGER NOT NULL,
   NomeCognome VARCHAR(30) NOT NULL,
   AnnoNascita INTEGER NOT NULL,
   Sesso VARCHAR(1) NOT NULL,
   Afferisce INTEGER NOT NULL,

PRIMARY KEY P_Impiegati(Codice),

FOREIGN KEY F_Afferisce(Afferisce)
REFERENCES Dipartimenti
ON DELETE CASCADE )
;

CREATE TABLE Direttori
(  Codice INTEGER NOT NULL,
   AnnoDiNomina INTEGER NOT NULL,
   Dirige INTEGER NOT NULL,

PRIMARY KEY P_Direttori(Codice),

FOREIGN KEY F_DirImpiegati(Codice)
REFERENCES Impiegati
ON DELETE CASCADE,

FOREIGN KEY F_Direttore(Dirige)
REFERENCES Dipartimenti
ON DELETE NO ACTION )
;

CREATE TABLE Responsabili
(  Codice INTEGER NOT NULL,
   AnnoDiNomina INTEGER NOT NULL,

PRIMARY KEY P_Responsabili(Codice),

FOREIGN KEY F_RespImpiegati(Codice)
REFERENCES Impiegati
ON DELETE CASCADE )
;

CREATE TABLE Dipendenti
(  Codice INTEGER NOT NULL,
   CoordinatoDa INTEGER NOT NULL,

PRIMARY KEY P_Dipendenti(Codice),

FOREIGN KEY F_DipImpiegati(Codice)
REFERENCES Impiegati
ON DELETE CASCADE,

FOREIGN KEY F_CoordinatoDa(CoordinatoDa)
REFERENCES Responsabili
ON DELETE NO ACTION )
;

CREATE TABLE Familiari
(  Nome VARCHAR(15) NOT NULL,
   CapoFamiglia INTEGER NOT NULL,
   AnnoNascita INTEGER,
   RelazioneParentela VARCHAR(8) NOT NULL,
   Sesso VARCHAR(1) NOT NULL,
   
PRIMARY KEY P_Familiari(CapoFamiglia,Nome),

FOREIGN KEY F_CapoFamiglia(CapoFamiglia)
REFERENCES Impiegati
ON DELETE CASCADE    )
;

CREATE TABLE Progetti
(  NumeroP INTEGER NOT NULL, 
   NomeP VARCHAR(10) NOT NULL,
   GestitoDa INTEGER ,
PRIMARY KEY P_Progetti(NumeroP),

FOREIGN KEY F_GestitoDa(GestitoDa)
REFERENCES Dipartimenti
ON DELETE NO ACTION    )
;

CREATE TABLE Partecipazioni
(  Impiegato INTEGER NOT NULL,
   Progetto INTEGER NOT NULL,
   Impegno INTEGER,
   
PRIMARY KEY P_Partecipazioni(Impiegato,Progetto),

FOREIGN KEY F_Impiegato(Impiegato)
REFERENCES Impiegati
ON DELETE CASCADE,

FOREIGN KEY F_Progetto(Progetto)
REFERENCES Progetti
ON DELETE CASCADE    )
;

CREATE VIEW DatiDirettori (Codice, NomeCognome, Sesso, AnnoNascita, Afferisce, Dirige, AnnoNomina)
 AS SELECT i.Codice, i.NomeCognome, i.Sesso, i.AnnoNascita, i.Afferisce, d.Dirige, d.AnnoDiNomina
  FROM Impiegati i, Direttori d
  WHERE i.Codice = d.Codice
  ;
   
CREATE VIEW DatiResponsabili (Codice, NomeCognome, Sesso, AnnoNascita, Afferisce, AnnoNomina)
 AS SELECT i.Codice, i.NomeCognome, i.Sesso, i.AnnoNascita, i.Afferisce, r.AnnoDiNomina
  FROM Impiegati i, Responsabili r
  WHERE i.Codice = r.Codice
  ;
 
 CREATE VIEW DatiDipendenti (Codice, NomeCognome, Sesso, AnnoNascita, Afferisce, CoordinatoDa)
 AS SELECT i.Codice, i.NomeCognome, i.Sesso, i.AnnoNascita, i.Afferisce, d.CoordinatoDa
  FROM Impiegati i, Dipendenti d
  WHERE i.Codice = d.Codice
  ;

insert into Dipartimenti values(1,'Informatica','Pisa');
insert into Dipartimenti values(2,'Vendite','Pisa');
insert into Dipartimenti values(3,'Telecomunicazioni','Pisa');
insert into Dipartimenti values(4,'Acquisti','Pisa');
insert into Dipartimenti values(5,'Personale','Pisa');
insert into Dipartimenti values(6,'Applicazioni','Pisa');
insert into Dipartimenti values(7,'Amministrazione','Pisa');
insert into Dipartimenti values(8,'Telecomunicazioni','Venezia');
insert into Dipartimenti values(9,'Hardware','Venezia');
insert into Dipartimenti values(10,'Informatica','Venezia');
insert into Dipartimenti values(11,'Amministrazione','Venezia');
insert into Dipartimenti values(12,'Magazzino','Venezia');
insert into Dipartimenti values(13,'Vendite','Venezia');
insert into Dipartimenti values(14,'Pubblicita','Venezia');
insert into Dipartimenti values(15,'Telecomunicazioni','Firenze');
insert into Dipartimenti values(16,'Acquisti','Firenze');
insert into Dipartimenti values(17,'Vendite','Firenze');
insert into Dipartimenti values(18,'Addestramento','Firenze');
insert into Dipartimenti values(19,'Risorse Umane','Firenze');
insert into Dipartimenti values(20,'Applicazioni','Firenze');

insert into Impiegati values(1, 'Carlo Accettella', 1987, 'm', 1);
insert into Impiegati values(2, 'Marco Angiolini', 1987, 'm', 10);
insert into Impiegati values(3, 'Daniele Azzarelli', 1987, 'm', 12);
insert into Impiegati values(4, 'Federica Baconcini', 1987, 'f', 20);
insert into Impiegati values(5, 'Miriam Baglioni', 1987, 'm', 10);
insert into Impiegati values(6, 'Barbara Baldini', 1987, 'f', 8);
insert into Impiegati values(7, 'Renata Bandelloni', 1987, 'f', 18);
insert into Impiegati values(8, 'Alessandro Banti', 1987, 'm', 2);
insert into Impiegati values(9, 'Daniela Barbieri', 1987, 'f', 14);
insert into Impiegati values(10, 'Massimo Bartoletti', 1987, 'm', 5);
insert into Impiegati values(11, 'Andrea Bello', 1987, 'm', 11);
insert into Impiegati values(12, 'Antonio Berti', 1987, 'm', 9);
insert into Impiegati values(13, 'Ulisse Bertocchi', 1987, 'm', 17);
insert into Impiegati values(14, 'Simone Betti', 1987, 'm', 14);
insert into Impiegati values(15, 'Simone Bevilacqua', 1986, 'm', 4);
insert into Impiegati values(16, 'Irene Biancalani', 1986, 'm', 16);
insert into Impiegati values(17, 'Cristian Bianchi', 1986, 'm', 10);
insert into Impiegati values(18, 'Cinzia Brazzini', 1986, 'f', 16);
insert into Impiegati values(19, 'Cristian Burrini', 1986, 'm', 8);
insert into Impiegati values(20, 'Francesco Calo', 1986, 'm', 10);
insert into Impiegati values(21, 'Massimo Camellini', 1986, 'm', 4);
insert into Impiegati values(22, 'Tiziana Cammilli', 1986, 'f', 7);
insert into Impiegati values(23, 'Marco Carbone', 1986, 'm', 6);
insert into Impiegati values(24, 'Franco Cardillo', 1986, 'm', 14);
insert into Impiegati values(25, 'Gianluca Caruso', 1986, 'm', 20);
insert into Impiegati values(26, 'Domenico Cerasuolo', 1986, 'm', 14);
insert into Impiegati values(27, 'Letizia Ciaccio', 1986, 'f', 16);
insert into Impiegati values(28, 'Carmine Ciavarella', 1986, 'm', 1);
insert into Impiegati values(29, 'Catia Cimino', 1986, 'f', 6);
insert into Impiegati values(30, 'Tiziana Cimoli', 1986, 'f', 13);
insert into Impiegati values(31, 'Matteo Coccia', 1986, 'm', 10);
insert into Impiegati values(32, 'Sara Colantonio', 1988, 'f', 3);
insert into Impiegati values(33, 'Francesco Correani', 1988, 'm', 6);
insert into Impiegati values(34, 'Laura DeGiorgi', 1988, 'f', 16);
insert into Impiegati values(35, 'Patrizio DeMichele', 1988, 'm', 2);
insert into Impiegati values(36, 'MariaRita DeMicheli', 1988, 'f', 2);
insert into Impiegati values(37, 'Franca Debole', 1988, 'f', 8);
insert into Impiegati values(38, 'Stefano DelCarlo', 1988, 'm', 15);
insert into Impiegati values(39, 'Riccardo Deri', 1988, 'm', 2);
insert into Impiegati values(40, 'MariaGrazia DiBono', 1988, 'f', 10);
insert into Impiegati values(41, 'Tiziano Fagni', 1988, 'm', 14);
insert into Impiegati values(42, 'Claudia Falcioni', 1988, 'f', 18);
insert into Impiegati values(43, 'Alessandro Falleni', 1988, 'm', 2);
insert into Impiegati values(44, 'Gaetano Fichera', 1988, 'm', 10);
insert into Impiegati values(45, 'Gianni Franceschini', 1988, 'm', 6);
insert into Impiegati values(46, 'Raffaele Fusto', 1988, 'm', 10);
insert into Impiegati values(47, 'CarmelaAnna Gallo', 1988, 'f', 18);
insert into Impiegati values(48, 'Alessandro Galluzzo', 1988, 'm', 16);
insert into Impiegati values(49, 'Antonio Gargano', 1988, 'm', 4);
insert into Impiegati values(50, 'Ilaria Giaconi', 1988, 'f', 10);
insert into Impiegati values(51, 'Gianni Ginesi', 1988, 'm', 16);
insert into Impiegati values(52, 'Cristian Gozzi', 1988, 'm', 20);
insert into Impiegati values(53, 'Riccardo Granchi', 1988, 'm', 20);
insert into Impiegati values(54, 'Tommaso Granchi', 1988, 'm', 14);
insert into Impiegati values(55, 'Emanuele Granucci', 1988, 'm', 4);
insert into Impiegati values(56, 'Natalina Grasso', 1988, 'f', 20);
insert into Impiegati values(57, 'Stefano Grimaldi', 1988, 'm', 12);
insert into Impiegati values(58, 'Alida Isolani', 1988, 'f', 4);
insert into Impiegati values(59, 'Gianluca LaPira', 1985, 'm', 18);
insert into Impiegati values(60, 'Ruggero Lanotte', 1985, 'm', 6);
insert into Impiegati values(61, 'Riccardo Lazzarini', 1985, 'm', 8);
insert into Impiegati values(62, 'Massimo Leonardo', 1985, 'm', 4);
insert into Impiegati values(63, 'Marco Lettere', 1985, 'm', 16);
insert into Impiegati values(64, 'Francesco Logozzo', 1985, 'm', 8);
insert into Impiegati values(65, 'Erika Lutri', 1985, 'f', 16);
insert into Impiegati values(66, 'Sergio Maffeis', 1985, 'm', 20);
insert into Impiegati values(67, 'Giada Maggienti', 1985, 'f', 16);
insert into Impiegati values(68, 'Annalisa Marabotta', 1985, 'f', 14);
insert into Impiegati values(69, 'Simone Marchi', 1985, 'm', 14);
insert into Impiegati values(70, 'Marco Martino', 1985, 'm', 12);
insert into Impiegati values(71, 'Laura Mattei', 1985, 'f', 10);
insert into Impiegati values(72, 'Fulvio Mazzaro', 1985, 'm', 18);
insert into Impiegati values(73, 'Paola Natale', 1985, 'f', 18);
insert into Impiegati values(74, 'Roberto Nottoli', 1985, 'm', 12);
insert into Impiegati values(75, 'Stefano Oliviero', 1985, 'm', 16);
insert into Impiegati values(76, 'Michele Orlandi', 1985, 'm', 14);
insert into Impiegati values(77, 'Francesco Pantaleo', 1985, 'm', 8);
insert into Impiegati values(78, 'Simone Paolinelli', 1985, 'm', 20);
insert into Impiegati values(79, 'Cinzia Partigliani', 1985, 'f', 10);
insert into Impiegati values(80, 'Nicola Petruzzellis', 1985, 'f', 4);
insert into Impiegati values(81, 'Attilia Pezzica', 1985, 'f', 2);
insert into Impiegati values(82, 'Giuseppe Piccoli', 1984, 'm', 18);
insert into Impiegati values(83, 'Michele Pierini', 1984, 'm', 8);
insert into Impiegati values(84, 'Diego Puppin', 1984, 'm', 12);
insert into Impiegati values(85, 'Andrea Rampini', 1984, 'm', 6);
insert into Impiegati values(86, 'Elisa Recchia', 1984, 'f', 16);
insert into Impiegati values(87, 'Giovanni Ricci', 1984, 'm', 10);
insert into Impiegati values(88, 'Francesco Ricci', 1984, 'm', 16);
insert into Impiegati values(89, 'Gianluca Rizzelli', 1984, 'm', 4);
insert into Impiegati values(90, 'Andrea Rocchi', 1984, 'm', 4);
insert into Impiegati values(91, 'Antonio Roggio', 1984, 'm', 14);
insert into Impiegati values(92, 'Andrea Romei', 1984, 'm', 16);
insert into Impiegati values(93, 'Pablo Rossi', 1984, 'm', 18);
insert into Impiegati values(94, 'Fabrizio Sanna', 1984, 'm', 14);
insert into Impiegati values(95, 'Alessandro Sbrasini', 1984, 'm', 20);
insert into Impiegati values(96, 'Antonio Schiavone', 1984, 'm', 12);
insert into Impiegati values(97, 'Luigi Scrimitore', 1984, 'm', 10);
insert into Impiegati values(98, 'Simone Semprini', 1984, 'm', 10);
insert into Impiegati values(99, 'Fabrizio Silvestri', 1984, 'm', 16);
insert into Impiegati values(100, 'Federico Siri', 1984, 'm', 14);
insert into Impiegati values(101, 'Chigen Strambi', 1984, 'm', 2);
insert into Impiegati values(102, 'Silvia Terreni', 1984, 'f', 20);
insert into Impiegati values(103, 'Samuele Tofano', 1984, 'm', 4);
insert into Impiegati values(104, 'Monica Turri', 1984, 'f', 6);
insert into Impiegati values(105, 'Cristina Vagnini', 1984, 'f', 16);
insert into Impiegati values(106, 'Marco Vannucci', 1984, 'm', 6);
insert into Impiegati values(107, 'Loredana Versienti', 1984, 'f', 18);
insert into Impiegati values(108, 'Francesco Zappa', 1984, 'm', 2);
insert into Impiegati values(109, 'Gloria Zembo', 1984, 'f', 2);
insert into Impiegati values(110, 'Simone Zipoli', 1984, 'm', 10);
insert into Impiegati values(111, 'Daniele Azzarelli', 1987, 'm', 14);
insert into Impiegati values(112, 'Massimo Cecchi', 1987, 'm', 8);
insert into Impiegati values(113, 'Emanuele Gagliano', 1987, 'm', 20);
insert into Impiegati values(114, 'Alessandro Galligani', 1987, 'm', 6);
insert into Impiegati values(115, 'Alessandro Galluzzo', 1987, 'm', 6);
insert into Impiegati values(116, 'Antonio Gargano', 1987, 'm', 2);
insert into Impiegati values(117, 'Angelo Gazze', 1987, 'm', 18);
insert into Impiegati values(118, 'Angela Gentile', 1987, 'f', 10);
insert into Impiegati values(119, 'Ilenia Gentili', 1987, 'f', 10);
insert into Impiegati values(120, 'Filippo Geraci', 1987, 'm', 12);
insert into Impiegati values(121, 'Pietro Giorgiann', 1987, 'm', 4);
insert into Impiegati values(122, 'Angela Grisafi', 1987, 'f', 18);
insert into Impiegati values(123, 'Oliwia Kuniczuk', 1987, 'f', 6);
insert into Impiegati values(124, 'Carmelo Iannello', 1987, 'm', 6);
insert into Impiegati values(125, 'Ivan Lanese', 1987, 'm', 14);
insert into Impiegati values(126, 'Francesca Lonetti', 1987, 'f', 20);
insert into Impiegati values(127, 'Carmela Luongo', 1987, 'f', 12);
insert into Impiegati values(128, 'Silvia Magini', 1987, 'f', 2);
insert into Impiegati values(129, 'Luca Manganelli', 1987, 'm', 12);
insert into Impiegati values(130, 'Michele Marconcini', 1987, 'm', 14);
insert into Impiegati values(131, 'Giulio Massei', 1987, 'm', 4);
insert into Impiegati values(132, 'Manuela Miconi', 1987, 'f', 14);
insert into Impiegati values(133, 'Stefano Moncelli', 1987, 'm', 12);
insert into Impiegati values(134, 'Dario Morina', 1987, 'm', 10);
insert into Impiegati values(135, 'Ilaria Nani', 1987, 'f', 2);
insert into Impiegati values(136, 'Roberto Nottoli', 1987, 'm', 20);
insert into Impiegati values(137, 'Michela Novellini', 1987, 'f', 20);
insert into Impiegati values(138, 'Enrico Ottonello', 1986, 'm', 18);
insert into Impiegati values(139, 'Antonio Palumbo', 1986, 'm', 20);
insert into Impiegati values(140, 'Simone Paolinelli', 1986, 'm', 6);
insert into Impiegati values(141, 'Marco Peccianti', 1986, 'm', 2);
insert into Impiegati values(142, 'Alessandro Petrocelli', 1986, 'm', 20);
insert into Impiegati values(143, 'Gabriele Pieri', 1986, 'm', 12);
insert into Impiegati values(144, 'Francesca Pietra', 1986, 'f', 8);
insert into Impiegati values(145, 'Edoardo Pistoletti', 1986, 'm', 16);
insert into Impiegati values(146, 'Laura Potiti', 1986, 'f', 2);
insert into Impiegati values(147, 'Elena Ratti', 1986, 'f', 4);
insert into Impiegati values(148, 'Diego Ratti', 1986, 'm', 4);
insert into Impiegati values(149, 'Enzo Reveglia', 1986, 'm', 20);
insert into Impiegati values(150, 'Massimo Ricci', 1986, 'm', 16);
insert into Impiegati values(151, 'Marco Risati', 1986, 'm', 14);
insert into Impiegati values(152, 'Rose Rossiello', 1986, 'm', 6);
insert into Impiegati values(153, 'Gianluca Sanna', 1986, 'm', 6);
insert into Impiegati values(154, 'Alessandro Sbrasini', 1986, 'm', 8);
insert into Impiegati values(155, 'Luca Scarponi', 1986, 'm', 2);
insert into Impiegati values(156, 'Luigi Scrimitore', 1986, 'm', 10);
insert into Impiegati values(157, 'Michela Silvestri', 1986, 'f', 4);
insert into Impiegati values(158, 'Giuseppe Sgattoni', 1986, 'm', 4);
insert into Impiegati values(159, 'Chris Sonetti', 1986, 'm', 8);
insert into Impiegati values(160, 'Carlo Spagoni', 1986, 'm', 6);
insert into Impiegati values(161, 'Chigeun Strambi', 1986, 'm', 16);
insert into Impiegati values(162, 'Paolo Tomei', 1986, 'm', 12);
insert into Impiegati values(163, 'Agostino Torsello', 1986, 'm', 20);
insert into Impiegati values(164, 'Luca Ventura', 1986, 'm', 6);
insert into Impiegati values(165, 'Gianni Virdis', 1986, 'm', 16);
insert into Impiegati values(166, 'Pietro Vitale', 1986, 'm', 18);
insert into Impiegati values(167, 'Luciano Vitiello', 1986, 'm', 18);
insert into Impiegati values(168, 'Andrea Zani', 1986, 'm', 8);
insert into Impiegati values(169, 'Corrado Zoccolo', 1986, 'm', 12);

insert into Direttori values (28, 2001, 1);
insert into Direttori values (146, 1998, 2);
insert into Direttori values (32, 2002, 3);
insert into Direttori values (21, 1997, 4);
insert into Direttori values (10, 2003, 5);
insert into Direttori values (29, 2003, 6);
insert into Direttori values (22, 2001, 7);
insert into Direttori values (159, 2005, 8);
insert into Direttori values (12, 1999, 9);
insert into Direttori values (31, 2000, 10);
insert into Direttori values (11, 2001, 11);
insert into Direttori values (162, 2000, 12);
insert into Direttori values (30, 1995, 13);
insert into Direttori values (132, 2004, 14);
insert into Direttori values (38, 2000, 15);
insert into Direttori values (16, 2004, 16);
insert into Direttori values (13, 2005, 17);
insert into Direttori values (167, 1997, 18);
insert into Direttori values (1, 2003, 19);
insert into Direttori values (163, 2003, 20);

insert into Responsabili values (119, 2002); 
insert into Responsabili values (142, 2002); 
insert into Responsabili values (162, 2000); 
insert into Responsabili values (132, 1996); 
insert into Responsabili values (134, 1999); 
insert into Responsabili values (138, 1999); 
insert into Responsabili values (146, 1997); 
insert into Responsabili values (149, 1997); 
insert into Responsabili values (15, 1999); 
insert into Responsabili values (150, 1997); 
insert into Responsabili values (151, 2000); 
insert into Responsabili values (155, 1999); 
insert into Responsabili values (156, 1996); 
insert into Responsabili values (159, 1997); 
insert into Responsabili values (161, 1996); 
insert into Responsabili values (163, 1996); 
insert into Responsabili values (165, 2000); 
insert into Responsabili values (166, 2004); 
insert into Responsabili values (167, 1997); 
insert into Responsabili values (168, 2003); 
insert into Responsabili values (169, 1997); 
insert into Responsabili values (21, 2002); 
insert into Responsabili values (23, 1997); 
insert into Responsabili values (29, 2001); 
insert into Responsabili values (33, 2000); 

insert into Dipendenti values(100, 151);
insert into Dipendenti values(101, 146);
insert into Dipendenti values(102, 149);
insert into Dipendenti values(103, 21);
insert into Dipendenti values(104, 23);
insert into Dipendenti values(105, 165);
insert into Dipendenti values(106, 29);
insert into Dipendenti values(107, 167);
insert into Dipendenti values(108, 155);
insert into Dipendenti values(109, 155);
insert into Dipendenti values(110, 156);
insert into Dipendenti values(111, 151);
insert into Dipendenti values(112, 168);
insert into Dipendenti values(113, 149);
insert into Dipendenti values(114, 29);
insert into Dipendenti values(115, 29);
insert into Dipendenti values(116, 155);
insert into Dipendenti values(117, 167);
insert into Dipendenti values(118, 156);
insert into Dipendenti values(120, 169);
insert into Dipendenti values(121, 21);
insert into Dipendenti values(122, 167);
insert into Dipendenti values(123, 29);
insert into Dipendenti values(124, 33);
insert into Dipendenti values(125, 151);
insert into Dipendenti values(126, 163);
insert into Dipendenti values(127, 169);
insert into Dipendenti values(128, 155);
insert into Dipendenti values(129, 169);
insert into Dipendenti values(130, 151);
insert into Dipendenti values(131, 21);
insert into Dipendenti values(133, 169);
insert into Dipendenti values(135, 155);
insert into Dipendenti values(136, 163);
insert into Dipendenti values(137, 163);
insert into Dipendenti values(139, 163);
insert into Dipendenti values(14, 132);
insert into Dipendenti values(140, 33);
insert into Dipendenti values(141, 155);
insert into Dipendenti values(143, 169);
insert into Dipendenti values(144, 168);
insert into Dipendenti values(145, 165);
insert into Dipendenti values(147, 21);
insert into Dipendenti values(148, 21);
insert into Dipendenti values(152, 33);
insert into Dipendenti values(153, 33);
insert into Dipendenti values(154, 168);
insert into Dipendenti values(157, 21);
insert into Dipendenti values(158, 21);
insert into Dipendenti values(160, 33);
insert into Dipendenti values(164, 33);
insert into Dipendenti values(17, 119);
insert into Dipendenti values(18, 150);
insert into Dipendenti values(19, 159);
insert into Dipendenti values(2, 119);
insert into Dipendenti values(20, 119);
insert into Dipendenti values(24, 132);
insert into Dipendenti values(25, 142);
insert into Dipendenti values(26, 132);
insert into Dipendenti values(27, 150);
insert into Dipendenti values(3, 162);
insert into Dipendenti values(34, 161);
insert into Dipendenti values(35, 146);
insert into Dipendenti values(36, 146);
insert into Dipendenti values(37, 159);
insert into Dipendenti values(39, 146);
insert into Dipendenti values(4, 142);
insert into Dipendenti values(40, 134);
insert into Dipendenti values(41, 132);
insert into Dipendenti values(42, 166);
insert into Dipendenti values(43, 146);
insert into Dipendenti values(44, 134);
insert into Dipendenti values(45, 23);
insert into Dipendenti values(46, 134);
insert into Dipendenti values(47, 166);
insert into Dipendenti values(48, 161);
insert into Dipendenti values(49, 15);
insert into Dipendenti values(5, 119);
insert into Dipendenti values(50, 134);
insert into Dipendenti values(51, 161);
insert into Dipendenti values(52, 142);
insert into Dipendenti values(53, 142);
insert into Dipendenti values(54, 132);
insert into Dipendenti values(55, 15);
insert into Dipendenti values(56, 142);
insert into Dipendenti values(57, 162);
insert into Dipendenti values(58, 15);
insert into Dipendenti values(59, 166);
insert into Dipendenti values(6, 159);
insert into Dipendenti values(60, 23);
insert into Dipendenti values(61, 168);
insert into Dipendenti values(62, 15);
insert into Dipendenti values(63, 161);
insert into Dipendenti values(64, 168);
insert into Dipendenti values(65, 161);
insert into Dipendenti values(66, 149);
insert into Dipendenti values(67, 161);
insert into Dipendenti values(68, 132);
insert into Dipendenti values(69, 151);
insert into Dipendenti values(7, 138);
insert into Dipendenti values(70, 162);
insert into Dipendenti values(71, 134);
insert into Dipendenti values(72, 166);
insert into Dipendenti values(73, 166);
insert into Dipendenti values(74, 162);
insert into Dipendenti values(75, 165);
insert into Dipendenti values(76, 151);
insert into Dipendenti values(77, 168);
insert into Dipendenti values(78, 149);
insert into Dipendenti values(79, 134);
insert into Dipendenti values(8, 146);
insert into Dipendenti values(80, 15);
insert into Dipendenti values(81, 146);
insert into Dipendenti values(82, 167);
insert into Dipendenti values(83, 168);
insert into Dipendenti values(84, 162);
insert into Dipendenti values(85, 23);
insert into Dipendenti values(86, 165);
insert into Dipendenti values(87, 156);
insert into Dipendenti values(88, 165);
insert into Dipendenti values(89, 21);
insert into Dipendenti values(9, 132);
insert into Dipendenti values(90, 21);
insert into Dipendenti values(91, 151);
insert into Dipendenti values(92, 165);
insert into Dipendenti values(93, 167);
insert into Dipendenti values(94, 151);
insert into Dipendenti values(95, 149);
insert into Dipendenti values(96, 169);
insert into Dipendenti values(97, 156);
insert into Dipendenti values(98, 156);
insert into Dipendenti values(99, 165);


insert into Familiari values('Francesco',1,1992,'figlio','m');
insert into Familiari values('Giada',2,1998,'figlio','f');
insert into Familiari values('Agostino',3,2000,'figlio','m');
insert into Familiari values('Alessandro',4,1994,'figlio','m');
insert into Familiari values('Alessandro',5,2000,'figlio','m');
insert into Familiari values('Alessandro',6,1998,'figlio','m');
insert into Familiari values('Alessandro',7,2000,'figlio','m');
insert into Familiari values('Alessandro',8,2000,'figlio','m');
insert into Familiari values('Alessandro',9,1992,'figlio','m');
insert into Familiari values('Alessandro',10,1994,'figlio','m');
insert into Familiari values('Alessandro',11,1998,'figlio','m');
insert into Familiari values('Alida',12,1994,'figlio','f');
insert into Familiari values('Andrea',13,1992,'figlio','m');
insert into Familiari values('Andrea',14,1996,'figlio','m');
insert into Familiari values('Andrea',15,1994,'figlio','m');
insert into Familiari values('Andrea',16,1998,'figlio','m');
insert into Familiari values('Andrea',17,1994,'figlio','m');
insert into Familiari values('Angela',18,1994,'figlio','f');
insert into Familiari values('Angela',19,2000,'figlio','f');
insert into Familiari values('Angelo',20,1992,'figlio','m');
insert into Familiari values('Annalisa',21,1992,'figlio','f');
insert into Familiari values('Antonio',22,2000,'figlio','m');
insert into Familiari values('Antonio',23,1998,'figlio','m');
insert into Familiari values('Antonio',24,2000,'figlio','m');
insert into Familiari values('Antonio',25,1992,'figlio','m');
insert into Familiari values('Antonio',26,1998,'figlio','m');
insert into Familiari values('Antonio',27,1998,'figlio','m');
insert into Familiari values('Attilia',28,2000,'figlio','f');
insert into Familiari values('Barbara',29,1996,'figlio','f');
insert into Familiari values('Carlo',30,1996,'figlio','m');
insert into Familiari values('Carlo',31,1996,'figlio','m');
insert into Familiari values('Carmela',32,1996,'figlio','f');
insert into Familiari values('CarmelaAnna',33,1994,'figlio','f');
insert into Familiari values('Carmelo',34,1998,'figlio','m');
insert into Familiari values('Carmine',35,1992,'figlio','m');
insert into Familiari values('Catia',36,2000,'figlio','f');
insert into Familiari values('Chigen',37,1992,'figlio','m');
insert into Familiari values('Chigeun',38,1998,'figlio','m');
insert into Familiari values('Chris',39,2000,'figlio','m');
insert into Familiari values('Cinzia',40,1994,'figlio','f');
insert into Familiari values('Cinzia',41,2000,'figlio','f');
insert into Familiari values('Claudia',42,1996,'figlio','f');
insert into Familiari values('Corrado',43,1998,'figlio','m');
insert into Familiari values('Cristian',44,1992,'figlio','m');
insert into Familiari values('Cristian',45,2000,'figlio','m');
insert into Familiari values('Cristian',46,1998,'figlio','m');
insert into Familiari values('Cristina',47,1998,'figlio','f');
insert into Familiari values('Daniela',48,1994,'figlio','f');
insert into Familiari values('Daniele',49,2000,'figlio','m');
insert into Familiari values('Daniele',50,1992,'figlio','m');
insert into Familiari values('Dario',51,1992,'figlio','m');
insert into Familiari values('Diego',52,1992,'figlio','m');
insert into Familiari values('Diego',53,1998,'figlio','m');
insert into Familiari values('Domenico',54,2000,'figlio','m');
insert into Familiari values('Edoardo',55,1994,'figlio','m');
insert into Familiari values('Elena',56,2000,'figlio','f');
insert into Familiari values('Elisa',57,2000,'figlio','f');
insert into Familiari values('Emanuele',58,1998,'figlio','m');
insert into Familiari values('Emanuele',59,1994,'figlio','m');
insert into Familiari values('Enrico',60,1994,'figlio','m');
insert into Familiari values('Enzo',61,1998,'figlio','m');
insert into Familiari values('Erika',62,1996,'figlio','f');
insert into Familiari values('Fabrizio',63,1996,'figlio','m');
insert into Familiari values('Fabrizio',64,1992,'figlio','m');
insert into Familiari values('Federica',65,1996,'figlio','f');
insert into Familiari values('Federico',66,1992,'figlio','m');
insert into Familiari values('Filippo',67,1998,'figlio','m');
insert into Familiari values('Franca',68,1996,'figlio','f');
insert into Familiari values('Francesca',69,2000,'figlio','f');
insert into Familiari values('Francesca',70,2000,'figlio','f');
insert into Familiari values('Francesco',71,2000,'figlio','m');
insert into Familiari values('Francesco',72,1998,'figlio','m');
insert into Familiari values('Francesco',73,1992,'figlio','m');
insert into Familiari values('Francesco',74,1994,'figlio','m');
insert into Familiari values('Francesco',75,2000,'figlio','m');
insert into Familiari values('Franco',76,1998,'figlio','m');
insert into Familiari values('Fulvio',77,1996,'figlio','m');
insert into Familiari values('Gabriele',78,1998,'figlio','m');
insert into Familiari values('Gaetano',79,1994,'figlio','m');
insert into Familiari values('Gianluca',80,1994,'figlio','m');
insert into Familiari values('Gianluca',81,1992,'figlio','m');
insert into Familiari values('Gianluca',82,1998,'figlio','m');
insert into Familiari values('Gianluca',83,1998,'figlio','m');
insert into Familiari values('Gianni',84,1992,'figlio','m');
insert into Familiari values('Gianni',85,1992,'figlio','m');
insert into Familiari values('Gianni',86,2000,'figlio','m');
insert into Familiari values('Giovanni',87,1996,'figlio','m');
insert into Familiari values('Giulio',88,1994,'figlio','m');
insert into Familiari values('Giuseppe',89,1998,'figlio','m');
insert into Familiari values('Giuseppe',90,2000,'figlio','m');
insert into Familiari values('Gloria',91,1998,'figlio','f');
insert into Familiari values('Ilaria',92,2000,'figlio','f');
insert into Familiari values('Ilaria',93,1998,'figlio','f');
insert into Familiari values('Ilenia',94,1998,'figlio','f');
insert into Familiari values('Irene',95,1998,'figlio','m');
insert into Familiari values('Ivan',96,2000,'figlio','m');
insert into Familiari values('Laura',97,1998,'figlio','f');
insert into Familiari values('Laura',98,1994,'figlio','f');
insert into Familiari values('Laura',99,1992,'figlio','f');
insert into Familiari values('Letizia',100,1998,'figlio','f');
insert into Familiari values('Loredana',101,1998,'figlio','f');
insert into Familiari values('Luca',102,1998,'figlio','m');
insert into Familiari values('Luca',103,1998,'figlio','m');
insert into Familiari values('Luca',104,2000,'figlio','m');
insert into Familiari values('Luciano',105,1994,'figlio','m');
insert into Familiari values('Luigi',106,1996,'figlio','m');
insert into Familiari values('Luigi',107,1998,'figlio','m');
insert into Familiari values('Manuela',108,1994,'figlio','f');
insert into Familiari values('Marco',109,1996,'figlio','m');
insert into Familiari values('Marco',110,1996,'figlio','m');
insert into Familiari values('Marco',111,1992,'figlio','m');
insert into Familiari values('Marco',112,1998,'figlio','m');
insert into Familiari values('Marco',113,1992,'figlio','m');
insert into Familiari values('Marco',114,1998,'figlio','m');
insert into Familiari values('Marco',115,1996,'figlio','m');
insert into Familiari values('MariaGrazia',116,1998,'figlio','f');
insert into Familiari values('MariaRita',117,1992,'figlio','f');
insert into Familiari values('Massimo',118,2000,'figlio','m');
insert into Familiari values('Massimo',119,1994,'figlio','m');
insert into Familiari values('Massimo',120,1992,'figlio','m');
insert into Familiari values('Massimo',121,1994,'figlio','m');
insert into Familiari values('Massimo',122,1996,'figlio','m');
insert into Familiari values('Matteo',123,1992,'figlio','m');
insert into Familiari values('Michela',124,1996,'figlio','f');
insert into Familiari values('Michela',125,1992,'figlio','f');
insert into Familiari values('Michele',126,2000,'figlio','m');
insert into Familiari values('Michele',127,2000,'figlio','m');
insert into Familiari values('Michele',128,2000,'figlio','m');
insert into Familiari values('Miriam',129,1996,'figlio','m');
insert into Familiari values('Monica',130,1994,'figlio','f');
insert into Familiari values('Natalina',131,2000,'figlio','f');
insert into Familiari values('Nicola',132,1998,'figlio','f');
insert into Familiari values('Oliwia',133,1994,'figlio','f');
insert into Familiari values('Pablo',134,1994,'figlio','m');
insert into Familiari values('Paola',135,1992,'figlio','f');
insert into Familiari values('Paolo',136,1996,'figlio','m');
insert into Familiari values('Patrizio',137,1994,'figlio','m');
insert into Familiari values('Pietro',138,1996,'figlio','m');
insert into Familiari values('Pietro',139,1994,'figlio','m');
insert into Familiari values('Raffaele',140,1994,'figlio','m');
insert into Familiari values('Renata',141,1994,'figlio','f');
insert into Familiari values('Riccardo',142,1998,'figlio','m');
insert into Familiari values('Riccardo',143,1992,'figlio','m');
insert into Familiari values('Riccardo',144,1998,'figlio','m');
insert into Familiari values('Roberto',145,1994,'figlio','m');
insert into Familiari values('Roberto',146,1998,'figlio','m');
insert into Familiari values('Rose',147,1994,'figlio','m');
insert into Familiari values('Ruggero',148,1994,'figlio','m');
insert into Familiari values('Samuele',149,1994,'figlio','m');
insert into Familiari values('Sara',150,2000,'figlio','f');
insert into Familiari values('Sergio',151,1998,'figlio','m');
insert into Familiari values('Silvia',152,1996,'figlio','f');
insert into Familiari values('Silvia',153,1992,'figlio','f');
insert into Familiari values('Simone',154,1992,'figlio','m');
insert into Familiari values('Simone',155,1998,'figlio','m');
insert into Familiari values('Simone',156,1996,'figlio','m');
insert into Familiari values('Simone',157,1996,'figlio','m');
insert into Familiari values('Simone',158,1996,'figlio','m');
insert into Familiari values('Simone',159,2000,'figlio','m');
insert into Familiari values('Simone',160,1996,'figlio','m');
insert into Familiari values('Stefano',161,1998,'figlio','m');
insert into Familiari values('Stefano',162,2000,'figlio','m');
insert into Familiari values('Stefano',163,2000,'figlio','m');
insert into Familiari values('Stefano',164,1998,'figlio','m');
insert into Familiari values('Tiziana',165,2000,'figlio','f');
insert into Familiari values('Tiziana',166,1992,'figlio','f');
insert into Familiari values('Tiziano',167,1992,'figlio','m');
insert into Familiari values('Ulisse',1,1998,'figlio','m');
insert into Familiari values('Tommaso',2,1998,'figlio','m');
insert into Familiari values('Tiziano',3,1998,'figlio','m');
insert into Familiari values('Tiziana',4,1994,'figlio','f');
insert into Familiari values('Tiziana',5,1998,'figlio','f');
insert into Familiari values('Stefano',6,1996,'figlio','m');
insert into Familiari values('Stefano',7,1996,'figlio','m');
insert into Familiari values('Stefano',8,1994,'figlio','m');
insert into Familiari values('Stefano',9,1994,'figlio','m');
insert into Familiari values('Simone',10,2000,'figlio','m');
insert into Familiari values('Simone',11,1996,'figlio','m');
insert into Familiari values('Simone',12,1994,'figlio','m');
insert into Familiari values('Simone',13,1998,'figlio','m');
insert into Familiari values('Simone',14,1992,'figlio','m');
insert into Familiari values('Simone',15,1994,'figlio','m');
insert into Familiari values('Simone',16,2000,'figlio','m');
insert into Familiari values('Silvia',17,1992,'figlio','f');
insert into Familiari values('Silvia',18,1994,'figlio','f');
insert into Familiari values('Sergio',19,2000,'figlio','m');
insert into Familiari values('Sara',20,2000,'figlio','f');
insert into Familiari values('Samuele',21,2000,'figlio','m');
insert into Familiari values('Ruggero',22,1994,'figlio','m');
insert into Familiari values('Rose',23,1998,'figlio','m');
insert into Familiari values('Roberto',24,1996,'figlio','m');
insert into Familiari values('Roberto',25,1994,'figlio','m');
insert into Familiari values('Riccardo',26,1992,'figlio','m');
insert into Familiari values('Riccardo',27,1994,'figlio','m');
insert into Familiari values('Riccardo',28,2000,'figlio','m');
insert into Familiari values('Renata',29,1992,'figlio','f');
insert into Familiari values('Raffaele',30,2000,'figlio','m');
insert into Familiari values('Pietro',31,2000,'figlio','m');
insert into Familiari values('Pietro',32,1996,'figlio','m');
insert into Familiari values('Patrizio',33,1994,'figlio','m');
insert into Familiari values('Paolo',34,1992,'figlio','m');
insert into Familiari values('Paola',35,1992,'figlio','f');
insert into Familiari values('Pablo',36,1992,'figlio','m');
insert into Familiari values('Oliwia',37,1996,'figlio','f');
insert into Familiari values('Nicola',38,1992,'figlio','f');
insert into Familiari values('Natalina',39,1996,'figlio','f');
insert into Familiari values('Monica',40,1998,'figlio','f');
insert into Familiari values('Miriam',41,1998,'figlio','m');
insert into Familiari values('Michele',42,1994,'figlio','m');
insert into Familiari values('Michele',43,1996,'figlio','m');
insert into Familiari values('Michele',44,1992,'figlio','m');
insert into Familiari values('Michela',45,2000,'figlio','f');
insert into Familiari values('Michela',46,1992,'figlio','f');
insert into Familiari values('Matteo',47,1992,'figlio','m');
insert into Familiari values('Massimo',48,1996,'figlio','m');
insert into Familiari values('Massimo',49,1994,'figlio','m');
insert into Familiari values('Massimo',50,1994,'figlio','m');
insert into Familiari values('Massimo',51,2000,'figlio','m');
insert into Familiari values('Massimo',52,2000,'figlio','m');
insert into Familiari values('MariaRita',53,1992,'figlio','f');
insert into Familiari values('MariaGrazia',54,2000,'figlio','f');
insert into Familiari values('Marco',55,1998,'figlio','m');
insert into Familiari values('Marco',56,1992,'figlio','m');
insert into Familiari values('Marco',57,1994,'figlio','m');
insert into Familiari values('Marco',58,2000,'figlio','m');
insert into Familiari values('Marco',59,1998,'figlio','m');
insert into Familiari values('Marco',60,2000,'figlio','m');
insert into Familiari values('Marco',61,1994,'figlio','m');
insert into Familiari values('Manuela',62,1994,'figlio','f');
insert into Familiari values('Luigi',63,2000,'figlio','m');
insert into Familiari values('Luigi',64,1996,'figlio','m');
insert into Familiari values('Luciano',65,1994,'figlio','m');
insert into Familiari values('Luca',66,1996,'figlio','m');
insert into Familiari values('Luca',67,2000,'figlio','m');
insert into Familiari values('Luca',68,1994,'figlio','m');
insert into Familiari values('Loredana',69,1998,'figlio','f');
insert into Familiari values('Letizia',70,1998,'figlio','f');
insert into Familiari values('Laura',71,1992,'figlio','f');
insert into Familiari values('Laura',72,1992,'figlio','f');
insert into Familiari values('Laura',73,1992,'figlio','f');
insert into Familiari values('Ivan',74,1994,'figlio','m');
insert into Familiari values('Irene',75,1992,'figlio','m');
insert into Familiari values('Ilenia',76,1994,'figlio','f');
insert into Familiari values('Ilaria',77,1994,'figlio','f');
insert into Familiari values('Ilaria',78,1994,'figlio','f');
insert into Familiari values('Gloria',79,1994,'figlio','f');
insert into Familiari values('Giuseppe',80,1996,'figlio','m');
insert into Familiari values('Giuseppe',81,2000,'figlio','m');
insert into Familiari values('Giulio',82,1996,'figlio','m');
insert into Familiari values('Giovanni',83,1998,'figlio','m');
insert into Familiari values('Gianluca',87,1996,'figlio','m');
insert into Familiari values('Gianluca',88,1996,'figlio','m');
insert into Familiari values('Gianluca',89,1996,'figlio','m');
insert into Familiari values('Gianluca',90,1998,'figlio','m');
insert into Familiari values('Gaetano',91,2000,'figlio','m');
insert into Familiari values('Gabriele',92,2000,'figlio','m');
insert into Familiari values('Fulvio',93,1994,'figlio','m');
insert into Familiari values('Franco',94,2000,'figlio','m');
insert into Familiari values('Francesco',95,1994,'figlio','m');
insert into Familiari values('Francesco',96,1994,'figlio','m');
insert into Familiari values('Francesco',97,1996,'figlio','m');
insert into Familiari values('Francesco',98,1996,'figlio','m');
insert into Familiari values('Francesco',99,1994,'figlio','m');
insert into Familiari values('Francesca',100,1992,'figlio','f');
insert into Familiari values('Francesca',101,2000,'figlio','f');
insert into Familiari values('Franca',102,2000,'figlio','f');
insert into Familiari values('Filippo',103,2000,'figlio','m');
insert into Familiari values('Federico',104,1994,'figlio','m');
insert into Familiari values('Federica',105,1998,'figlio','f');
insert into Familiari values('Fabrizio',106,2000,'figlio','m');
insert into Familiari values('Fabrizio',107,1992,'figlio','m');
insert into Familiari values('Erika',108,1996,'figlio','f');
insert into Familiari values('Enzo',109,1992,'figlio','m');
insert into Familiari values('Enrico',110,1998,'figlio','m');
insert into Familiari values('Emanuele',111,1994,'figlio','m');
insert into Familiari values('Emanuele',112,1994,'figlio','m');
insert into Familiari values('Elisa',113,1996,'figlio','f');
insert into Familiari values('Elena',114,2000,'figlio','f');
insert into Familiari values('Edoardo',115,1992,'figlio','m');
insert into Familiari values('Domenico',116,1998,'figlio','m');
insert into Familiari values('Diego',117,1994,'figlio','m');
insert into Familiari values('Diego',118,1996,'figlio','m');
insert into Familiari values('Dario',119,1992,'figlio','m');
insert into Familiari values('Daniele',120,1994,'figlio','m');
insert into Familiari values('Daniele',121,1996,'figlio','m');
insert into Familiari values('Daniela',122,1992,'figlio','f');
insert into Familiari values('Cristina',123,1994,'figlio','f');
insert into Familiari values('Cristian',124,1998,'figlio','m');
insert into Familiari values('Cristian',125,1992,'figlio','m');
insert into Familiari values('Cristian',126,2000,'figlio','m');
insert into Familiari values('Corrado',127,1996,'figlio','m');
insert into Familiari values('Claudia',128,1994,'figlio','f');
insert into Familiari values('Cinzia',129,2000,'figlio','f');
insert into Familiari values('Cinzia',130,1996,'figlio','f');
insert into Familiari values('Chris',131,1996,'figlio','m');
insert into Familiari values('Chigeun',132,1996,'figlio','m');
insert into Familiari values('Chigen',133,2000,'figlio','m');
insert into Familiari values('Catia',134,1996,'figlio','f');
insert into Familiari values('Carmine',135,1996,'figlio','m');
insert into Familiari values('Carmelo',136,1994,'figlio','m');
insert into Familiari values('CarmelaAnna',137,2000,'figlio','f');
insert into Familiari values('Carmela',138,1994,'figlio','f');
insert into Familiari values('Carlo',139,2000,'figlio','m');
insert into Familiari values('Carlo',140,1996,'figlio','m');
insert into Familiari values('Barbara',141,1998,'figlio','f');
insert into Familiari values('Attilia',142,1992,'figlio','f');
insert into Familiari values('Antonio',143,1998,'figlio','m');
insert into Familiari values('Antonio',144,1994,'figlio','m');
insert into Familiari values('Antonio',145,2000,'figlio','m');
insert into Familiari values('Antonio',146,1992,'figlio','m');
insert into Familiari values('Antonio',147,2000,'figlio','m');
insert into Familiari values('Antonio',148,1992,'figlio','m');
insert into Familiari values('Annalisa',149,1996,'figlio','f');
insert into Familiari values('Angelo',150,1992,'figlio','m');
insert into Familiari values('Angela',151,1992,'figlio','f');
insert into Familiari values('Angela',152,1992,'figlio','f');
insert into Familiari values('Andrea',153,1994,'figlio','m');
insert into Familiari values('Andrea',154,2000,'figlio','m');
insert into Familiari values('Andrea',155,1992,'figlio','m');
insert into Familiari values('Andrea',156,1992,'figlio','m');
insert into Familiari values('Andrea',157,2000,'figlio','m');
insert into Familiari values('Alida',158,1992,'figlio','f');
insert into Familiari values('Alessandro',159,1998,'figlio','m');
insert into Familiari values('Alessandro',160,1992,'figlio','m');
insert into Familiari values('Alessandro',161,2000,'figlio','m');
insert into Familiari values('Alessandro',162,1996,'figlio','m');
insert into Familiari values('Alessandro',163,1998,'figlio','m');
insert into Familiari values('Alessandro',164,1996,'figlio','m');
insert into Familiari values('Alessandro',165,2000,'figlio','m');
insert into Familiari values('Alessandro',166,1996,'figlio','m');
insert into Familiari values('Agostino',167,1992,'figlio','m');
insert into Familiari values('Carlo',1,1998,'figlio','m');
insert into Familiari values('Marco',2,1992,'figlio','m');
insert into Familiari values('Daniele',3,1998,'figlio','m');
insert into Familiari values('Federica',4,1992,'figlio','f');
insert into Familiari values('Miriam',5,1992,'figlio','m');
insert into Familiari values('Barbara',6,1992,'figlio','f');
insert into Familiari values('Renata',7,1994,'figlio','f');
insert into Familiari values('Daniela',9,1992,'figlio','f');
insert into Familiari values('Massimo',10,1992,'figlio','m');
insert into Familiari values('Andrea',11,1998,'figlio','m');
insert into Familiari values('Antonio',12,1996,'figlio','m');
insert into Familiari values('Ulisse',13,1996,'figlio','m');
insert into Familiari values('Irene',16,1998,'figlio','m');
insert into Familiari values('Cristian',17,1996,'figlio','m');
insert into Familiari values('Cinzia',18,1998,'figlio','f');
insert into Familiari values('Cristian',19,1996,'figlio','m');
insert into Familiari values('Francesco',20,1992,'figlio','m');
insert into Familiari values('Massimo',21,1996,'figlio','m');
insert into Familiari values('Tiziana',22,1998,'figlio','f');
insert into Familiari values('Marco',23,2000,'figlio','m');
insert into Familiari values('Franco',24,2000,'figlio','m');
insert into Familiari values('Gianluca',25,1996,'figlio','m');
insert into Familiari values('Domenico',26,2000,'figlio','m');
insert into Familiari values('Letizia',27,1994,'figlio','f');
insert into Familiari values('Carmine',28,2000,'figlio','m');
insert into Familiari values('Catia',29,1994,'figlio','f');
insert into Familiari values('Tiziana',30,1996,'figlio','f');
insert into Familiari values('Matteo',31,1992,'figlio','m');
insert into Familiari values('Sara',32,1998,'figlio','f');
insert into Familiari values('Francesco',33,2000,'figlio','m');
insert into Familiari values('Laura',34,2000,'figlio','f');
insert into Familiari values('Patrizio',35,1994,'figlio','m');
insert into Familiari values('MariaRita',36,1994,'figlio','f');
insert into Familiari values('Franca',37,1996,'figlio','f');
insert into Familiari values('Stefano',38,1998,'figlio','m');
insert into Familiari values('Riccardo',39,2000,'figlio','m');
insert into Familiari values('MariaGrazia',40,1996,'figlio','f');
insert into Familiari values('Tiziano',41,1996,'figlio','m');
insert into Familiari values('Alessandro',43,1998,'figlio','m');
insert into Familiari values('Gaetano',44,1996,'figlio','m');
insert into Familiari values('Gianni',45,2000,'figlio','m');
insert into Familiari values('Raffaele',46,1996,'figlio','m');
insert into Familiari values('CarmelaAnna',47,2000,'figlio','f');
insert into Familiari values('Alessandro',48,1994,'figlio','m');
insert into Familiari values('Antonio',49,1994,'figlio','m');
insert into Familiari values('Ilaria',50,1992,'figlio','f');
insert into Familiari values('Gianni',51,1996,'figlio','m');
insert into Familiari values('Cristian',52,1994,'figlio','m');
insert into Familiari values('Riccardo',53,1992,'figlio','m');
insert into Familiari values('Tommaso',54,1998,'figlio','m');
insert into Familiari values('Emanuele',55,1992,'figlio','m');
insert into Familiari values('Natalina',56,2000,'figlio','f');
insert into Familiari values('Stefano',57,1992,'figlio','m');
insert into Familiari values('Alida',58,1992,'figlio','f');
insert into Familiari values('Gianluca',59,2000,'figlio','m');
insert into Familiari values('Ruggero',60,1994,'figlio','m');
insert into Familiari values('Riccardo',61,1996,'figlio','m');
insert into Familiari values('Massimo',62,1998,'figlio','m');
insert into Familiari values('Marco',63,1996,'figlio','m');
insert into Familiari values('Francesco',64,1994,'figlio','m');
insert into Familiari values('Erika',65,2000,'figlio','f');
insert into Familiari values('Sergio',66,2000,'figlio','m');
insert into Familiari values('Giada',67,1992,'figlio','f');
insert into Familiari values('Annalisa',68,2000,'figlio','f');
insert into Familiari values('Simone',69,1998,'figlio','m');
insert into Familiari values('Marco',70,1992,'figlio','m');
insert into Familiari values('Fulvio',72,2000,'figlio','m');
insert into Familiari values('Paola',73,1998,'figlio','f');
insert into Familiari values('Roberto',74,2000,'figlio','m');
insert into Familiari values('Stefano',75,1996,'figlio','m');
insert into Familiari values('Michele',76,2000,'figlio','m');
insert into Familiari values('Francesco',77,1996,'figlio','m');
insert into Familiari values('Simone',78,1992,'figlio','m');
insert into Familiari values('Cinzia',79,1994,'figlio','f');
insert into Familiari values('Nicola',80,1998,'figlio','f');
insert into Familiari values('Attilia',81,1994,'figlio','f');
insert into Familiari values('Giuseppe',82,1992,'figlio','m');
insert into Familiari values('Michele',83,1994,'figlio','m');
insert into Familiari values('Diego',84,1996,'figlio','m');
insert into Familiari values('Andrea',85,1996,'figlio','m');
insert into Familiari values('Elisa',86,1992,'figlio','f');
insert into Familiari values('Francesco',88,1994,'figlio','m');
insert into Familiari values('Andrea',90,1992,'figlio','m');
insert into Familiari values('Antonio',91,2000,'figlio','m');
insert into Familiari values('Andrea',92,1998,'figlio','m');
insert into Familiari values('Pablo',93,1996,'figlio','m');
insert into Familiari values('Fabrizio',94,1992,'figlio','m');
insert into Familiari values('Alessandro',95,1992,'figlio','m');
insert into Familiari values('Antonio',96,2000,'figlio','m');
insert into Familiari values('Luigi',97,1996,'figlio','m');
insert into Familiari values('Simone',98,2000,'figlio','m');
insert into Familiari values('Fabrizio',99,1994,'figlio','m');
insert into Familiari values('Federico',100,2000,'figlio','m');
insert into Familiari values('Chigen',101,1998,'figlio','m');
insert into Familiari values('Silvia',102,2000,'figlio','f');
insert into Familiari values('Samuele',103,2000,'figlio','m');
insert into Familiari values('Monica',104,1996,'figlio','f');
insert into Familiari values('Cristina',105,1994,'figlio','f');
insert into Familiari values('Marco',106,1998,'figlio','m');
insert into Familiari values('Loredana',107,1998,'figlio','f');
insert into Familiari values('Francesco',108,2000,'figlio','m');
insert into Familiari values('Gloria',109,1994,'figlio','f');
insert into Familiari values('Simone',110,1998,'figlio','m');
insert into Familiari values('Daniele',111,1994,'figlio','m');
insert into Familiari values('Massimo',112,2000,'figlio','m');
insert into Familiari values('Emanuele',113,1992,'figlio','m');
insert into Familiari values('Alessandro',114,1998,'figlio','m');
insert into Familiari values('Alessandro',115,1998,'figlio','m');
insert into Familiari values('Antonio',116,1996,'figlio','m');
insert into Familiari values('Angelo',117,1992,'figlio','m');
insert into Familiari values('Angela',118,1994,'figlio','f');
insert into Familiari values('Ilenia',119,1998,'figlio','f');
insert into Familiari values('Filippo',120,1992,'figlio','m');
insert into Familiari values('Pietro',121,1996,'figlio','m');
insert into Familiari values('Angela',122,1996,'figlio','f');
insert into Familiari values('Oliwia',123,1992,'figlio','f');
insert into Familiari values('Carmelo',124,1992,'figlio','m');
insert into Familiari values('Ivan',125,1998,'figlio','m');
insert into Familiari values('Francesca',126,1992,'figlio','f');
insert into Familiari values('Carmela',127,1992,'figlio','f');
insert into Familiari values('Silvia',128,1996,'figlio','f');
insert into Familiari values('Luca',129,1996,'figlio','m');
insert into Familiari values('Michele',130,1992,'figlio','m');
insert into Familiari values('Giulio',131,1996,'figlio','m');
insert into Familiari values('Manuela',132,1996,'figlio','f');
insert into Familiari values('Stefano',133,1996,'figlio','m');
insert into Familiari values('Dario',134,1992,'figlio','m');
insert into Familiari values('Ilaria',135,1992,'figlio','f');
insert into Familiari values('Roberto',136,1992,'figlio','m');
insert into Familiari values('Michela',137,1992,'figlio','f');
insert into Familiari values('Enrico',138,1996,'figlio','m');
insert into Familiari values('Antonio',139,1994,'figlio','m');
insert into Familiari values('Simone',140,2000,'figlio','m');
insert into Familiari values('Marco',141,1998,'figlio','m');
insert into Familiari values('Alessandro',142,1992,'figlio','m');
insert into Familiari values('Gabriele',143,1992,'figlio','m');
insert into Familiari values('Francesca',144,1996,'figlio','f');
insert into Familiari values('Edoardo',145,2000,'figlio','m');
insert into Familiari values('Laura',146,1994,'figlio','f');
insert into Familiari values('Elena',147,1994,'figlio','f');
insert into Familiari values('Diego',148,1994,'figlio','m');
insert into Familiari values('Enzo',149,2000,'figlio','m');
insert into Familiari values('Massimo',150,2000,'figlio','m');
insert into Familiari values('Marco',151,1996,'figlio','m');
insert into Familiari values('Rose',152,1994,'figlio','m');
insert into Familiari values('Gianluca',153,1992,'figlio','m');
insert into Familiari values('Alessandro',154,1994,'figlio','m');
insert into Familiari values('Luca',155,1996,'figlio','m');
insert into Familiari values('Luigi',156,1996,'figlio','m');
insert into Familiari values('Michela',157,1994,'figlio','f');
insert into Familiari values('Giuseppe',158,1996,'figlio','m');
insert into Familiari values('Chris',159,1996,'figlio','m');
insert into Familiari values('Carlo',160,1998,'figlio','m');
insert into Familiari values('Chigeun',161,1994,'figlio','m');
insert into Familiari values('Paolo',162,1996,'figlio','m');
insert into Familiari values('Agostino',163,1994,'figlio','m');
insert into Familiari values('Luca',164,1994,'figlio','m');
insert into Familiari values('Gianni',165,1998,'figlio','m');
insert into Familiari values('Pietro',166,2000,'figlio','m');
insert into Familiari values('Luciano',167,1992,'figlio','m');

insert into Progetti values(1,'Progetto1',12);
insert into Progetti values(2,'Progetto2',20);
insert into Progetti values(3,'Progetto3',20);
insert into Progetti values(4,'Progetto4',14);
insert into Progetti values(5,'Progetto5',6);
insert into Progetti values(6,'Progetto6',18);
insert into Progetti values(7,'Progetto7',18);
insert into Progetti values(8,'Progetto8',10);
insert into Progetti values(9,'Progetto9',8);
insert into Progetti values(10,'Progetto10',12);
insert into Progetti values(11,'Progetto11',6);
insert into Progetti values(12,'Progetto12',4);
insert into Progetti values(13,'Progetto13',14);
insert into Progetti values(14,'Progetto14',6);
insert into Progetti values(15,'Progetto15',6);
insert into Progetti values(16,'Progetto16',8);
insert into Progetti values(17,'Progetto17',12);
insert into Progetti values(18,'Progetto18',6);
insert into Progetti values(19,'Progetto19',18);
insert into Progetti values(20,'Progetto20',12);
insert into Progetti values(21,'Progetto21',20);
insert into Progetti values(22,'Progetto22',14);
insert into Progetti values(23,'Progetto23',1);
insert into Progetti values(24,'Progetto24',16);
insert into Progetti values(25,'Progetto25',18);
insert into Progetti values(26,'Progetto26',8);
insert into Progetti values(27,'Progetto27',18);
insert into Progetti values(28,'Progetto28',14);
insert into Progetti values(29,'Progetto29',6);
insert into Progetti values(30,'Progetto30',10);
insert into Progetti values(31,'Progetto31',2);
insert into Progetti values(32,'Progetto32',2);
insert into Progetti values(33,'Progetto33',20);
insert into Progetti values(34,'Progetto34',12);
insert into Progetti values(35,'Progetto35',12);
insert into Progetti values(36,'Progetto36',18);
insert into Progetti values(37,'Progetto37',2);
insert into Progetti values(38,'Progetto38',10);
insert into Progetti values(39,'Progetto39',14);
insert into Progetti values(40,'Progetto40',8);
insert into Progetti values(41,'Progetto41',3);
insert into Progetti values(42,'Progetto42',3);


insert into Partecipazioni values(1,6,1);    
insert into Partecipazioni values(2,30,2);   
insert into Partecipazioni values(3,28,3);   
insert into Partecipazioni values(4,26,4);   
insert into Partecipazioni values(5,12,5);   
insert into Partecipazioni values(8,8,8);    
insert into Partecipazioni values(9,38,9);   
insert into Partecipazioni values(10,32,10); 
insert into Partecipazioni values(11,14,11);
insert into Partecipazioni values(12,20,12);
insert into Partecipazioni values(13,30,13);
insert into Partecipazioni values(14,40,14);
insert into Partecipazioni values(15,10,15);
insert into Partecipazioni values(16,24,16);
insert into Partecipazioni values(17,4,17);
insert into Partecipazioni values(18,26,18);
insert into Partecipazioni values(19,38,19);
insert into Partecipazioni values(20,6,20);
insert into Partecipazioni values(21,36,21);
insert into Partecipazioni values(22,26,22);
insert into Partecipazioni values(23,8,23);
insert into Partecipazioni values(24,2,24);
insert into Partecipazioni values(25,18,25);
insert into Partecipazioni values(26,40,26);
insert into Partecipazioni values(27,16,27);
insert into Partecipazioni values(29,20,29);
insert into Partecipazioni values(30,36,30);
insert into Partecipazioni values(31,6,31);
insert into Partecipazioni values(32,40,32);
insert into Partecipazioni values(33,40,33);
insert into Partecipazioni values(34,30,34);
insert into Partecipazioni values(35,4,35);
insert into Partecipazioni values(36,14,36);
insert into Partecipazioni values(37,18,37);
insert into Partecipazioni values(38,12,38);
insert into Partecipazioni values(39,28,39);
insert into Partecipazioni values(40,38,40);
insert into Partecipazioni values(41,34,41);
insert into Partecipazioni values(42,30,42);
insert into Partecipazioni values(43,34,43);
insert into Partecipazioni values(44,20,44);
insert into Partecipazioni values(45,28,45);
insert into Partecipazioni values(46,18,46);
insert into Partecipazioni values(47,36,47);
insert into Partecipazioni values(48,36,48);
insert into Partecipazioni values(49,26,49);
insert into Partecipazioni values(50,4,50);
insert into Partecipazioni values(51,38,51);
insert into Partecipazioni values(52,14,52);
insert into Partecipazioni values(53,36,53);
insert into Partecipazioni values(54,34,54);
insert into Partecipazioni values(55,16,55);
insert into Partecipazioni values(56,10,56);
insert into Partecipazioni values(57,16,57);
insert into Partecipazioni values(58,4,58);
insert into Partecipazioni values(59,18,59);
insert into Partecipazioni values(60,16,60);
insert into Partecipazioni values(61,8,61);
insert into Partecipazioni values(62,10,62);
insert into Partecipazioni values(63,34,63);
insert into Partecipazioni values(64,4,64);
insert into Partecipazioni values(65,16,65);
insert into Partecipazioni values(66,28,66);
insert into Partecipazioni values(67,2,67);
insert into Partecipazioni values(68,10,68);
insert into Partecipazioni values(69,14,69);
insert into Partecipazioni values(70,24,70);
insert into Partecipazioni values(71,24,71);
insert into Partecipazioni values(72,24,72);
insert into Partecipazioni values(73,12,73);
insert into Partecipazioni values(74,34,74);
insert into Partecipazioni values(75,40,75);
insert into Partecipazioni values(76,14,76);
insert into Partecipazioni values(77,4,77);
insert into Partecipazioni values(78,24,78);
insert into Partecipazioni values(79,38,79);
insert into Partecipazioni values(80,12,80);
insert into Partecipazioni values(81,6,81);
insert into Partecipazioni values(82,24,82);
insert into Partecipazioni values(83,32,83);
insert into Partecipazioni values(84,8,84);
insert into Partecipazioni values(85,26,85);
insert into Partecipazioni values(86,10,86);
insert into Partecipazioni values(87,38,87);
insert into Partecipazioni values(88,26,88);
insert into Partecipazioni values(89,2,89);
insert into Partecipazioni values(90,18,90);
insert into Partecipazioni values(91,2,91);
insert into Partecipazioni values(92,28,92);
insert into Partecipazioni values(93,10,93);
insert into Partecipazioni values(94,26,94);
insert into Partecipazioni values(95,2,95);
insert into Partecipazioni values(96,8,96);
insert into Partecipazioni values(97,38,97);
insert into Partecipazioni values(98,12,98);
insert into Partecipazioni values(99,8,99);
insert into Partecipazioni values(100,34,100);
insert into Partecipazioni values(101,4,101);
insert into Partecipazioni values(102,38,102);
insert into Partecipazioni values(103,12,103);
insert into Partecipazioni values(104,4,104);
insert into Partecipazioni values(105,38,105);
insert into Partecipazioni values(106,30,106);
insert into Partecipazioni values(107,12,107);
insert into Partecipazioni values(108,28,108);
insert into Partecipazioni values(109,22,109);
insert into Partecipazioni values(110,26,110);
insert into Partecipazioni values(111,36,111);
insert into Partecipazioni values(112,28,112);
insert into Partecipazioni values(113,24,113);
insert into Partecipazioni values(114,38,114);
insert into Partecipazioni values(115,34,115);
insert into Partecipazioni values(116,10,116);
insert into Partecipazioni values(117,16,117);
insert into Partecipazioni values(118,38,118);
insert into Partecipazioni values(119,10,119);
insert into Partecipazioni values(120,4,120);
insert into Partecipazioni values(121,38,121);
insert into Partecipazioni values(122,8,122);
insert into Partecipazioni values(123,4,123);
insert into Partecipazioni values(124,8,124);
insert into Partecipazioni values(125,4,125);
insert into Partecipazioni values(126,8,126);
insert into Partecipazioni values(127,28,127);
insert into Partecipazioni values(128,16,128);
insert into Partecipazioni values(129,26,129);
insert into Partecipazioni values(130,28,130);
insert into Partecipazioni values(131,8,131);
insert into Partecipazioni values(132,10,132);
insert into Partecipazioni values(133,26,133);
insert into Partecipazioni values(134,36,134);
insert into Partecipazioni values(135,24,135);
insert into Partecipazioni values(136,40,136);
insert into Partecipazioni values(137,16,137);
insert into Partecipazioni values(138,22,138);
insert into Partecipazioni values(139,10,139);
insert into Partecipazioni values(140,22,140);
insert into Partecipazioni values(141,32,141);
insert into Partecipazioni values(142,10,142);
insert into Partecipazioni values(143,20,143);
insert into Partecipazioni values(144,36,144);
insert into Partecipazioni values(145,12,145);
insert into Partecipazioni values(146,4,146);
insert into Partecipazioni values(147,4,147);
insert into Partecipazioni values(148,2,148);
insert into Partecipazioni values(149,34,149);
insert into Partecipazioni values(150,12,150);
insert into Partecipazioni values(151,22,151);
insert into Partecipazioni values(152,34,152);
insert into Partecipazioni values(153,36,153);
insert into Partecipazioni values(154,10,154);
insert into Partecipazioni values(155,28,155);
insert into Partecipazioni values(156,34,156);
insert into Partecipazioni values(157,34,157);
insert into Partecipazioni values(158,2,158);
insert into Partecipazioni values(159,36,159);
insert into Partecipazioni values(160,32,160);
insert into Partecipazioni values(161,34,161);
insert into Partecipazioni values(162,36,162);
insert into Partecipazioni values(163,26,163);
insert into Partecipazioni values(164,12,164);
insert into Partecipazioni values(165,20,165);
insert into Partecipazioni values(166,14,166);
insert into Partecipazioni values(167,18,167);
insert into Partecipazioni values(168,4,168);
insert into Partecipazioni values(169,18,169);
insert into Partecipazioni values(1,14,1);
insert into Partecipazioni values(2,20,2);
insert into Partecipazioni values(3,14,3);
insert into Partecipazioni values(4,18,4);
insert into Partecipazioni values(5,18,5);
insert into Partecipazioni values(6,41,20);
insert into Partecipazioni values(6,42,20);
insert into Partecipazioni values(2,38,20);
insert into Partecipazioni values(7,38,20);
insert into Partecipazioni values(7,30,20);
insert into Partecipazioni values(7,8,20);
insert into Partecipazioni values(8,40,8);
insert into Partecipazioni values(9,6,9);
insert into Partecipazioni values(10,30,10);
insert into Partecipazioni values(11,4,11);
insert into Partecipazioni values(12,32,12);
insert into Partecipazioni values(13,10,13);
insert into Partecipazioni values(14,6,14);
insert into Partecipazioni values(16,6,16);
insert into Partecipazioni values(17,36,17);
insert into Partecipazioni values(18,2,18);
insert into Partecipazioni values(19,26,19);
insert into Partecipazioni values(20,34,20);
insert into Partecipazioni values(21,8,21);
insert into Partecipazioni values(22,14,22);
insert into Partecipazioni values(23,18,23);
insert into Partecipazioni values(24,18,24);
insert into Partecipazioni values(25,30,25);
insert into Partecipazioni values(26,34,26);
insert into Partecipazioni values(27,32,27);
insert into Partecipazioni values(28,30,28);
insert into Partecipazioni values(29,8,29);
insert into Partecipazioni values(30,40,30);
insert into Partecipazioni values(31,28,31);
insert into Partecipazioni values(32,22,32);
insert into Partecipazioni values(33,10,33);
insert into Partecipazioni values(34,2,34);
insert into Partecipazioni values(35,30,35);
insert into Partecipazioni values(36,20,36);
insert into Partecipazioni values(37,30,37);
insert into Partecipazioni values(38,16,38);
insert into Partecipazioni values(39,22,39);
insert into Partecipazioni values(40,30,40);
insert into Partecipazioni values(41,6,41);
insert into Partecipazioni values(42,38,42);
insert into Partecipazioni values(43,12,43);
insert into Partecipazioni values(44,22,44);
insert into Partecipazioni values(45,34,45);
insert into Partecipazioni values(46,20,46);
insert into Partecipazioni values(47,2,47);
insert into Partecipazioni values(48,14,48);
insert into Partecipazioni values(49,10,49);
insert into Partecipazioni values(50,14,50);
insert into Partecipazioni values(51,34,51);
insert into Partecipazioni values(52,20,52);
insert into Partecipazioni values(53,14,53);
insert into Partecipazioni values(54,30,54);
insert into Partecipazioni values(55,18,55);
insert into Partecipazioni values(56,34,56);
insert into Partecipazioni values(57,30,57);
insert into Partecipazioni values(58,14,58);
insert into Partecipazioni values(60,30,60);
insert into Partecipazioni values(61,24,61);
insert into Partecipazioni values(62,28,62);
insert into Partecipazioni values(64,34,64);
insert into Partecipazioni values(65,4,65);
insert into Partecipazioni values(66,30,66);
insert into Partecipazioni values(67,32,67);
insert into Partecipazioni values(69,32,69);
insert into Partecipazioni values(70,22,70);
insert into Partecipazioni values(71,2,71);
insert into Partecipazioni values(72,32,72);
insert into Partecipazioni values(73,16,73);
insert into Partecipazioni values(74,40,74);
insert into Partecipazioni values(76,8,76);
insert into Partecipazioni values(77,10,77);
insert into Partecipazioni values(78,40,78);
insert into Partecipazioni values(79,20,79);
insert into Partecipazioni values(81,12,81);
insert into Partecipazioni values(82,38,82);
insert into Partecipazioni values(83,6,83);
insert into Partecipazioni values(84,4,84);
insert into Partecipazioni values(86,14,86);
insert into Partecipazioni values(87,30,87);
insert into Partecipazioni values(88,14,88);
insert into Partecipazioni values(89,34,89);
insert into Partecipazioni values(90,8,90);
insert into Partecipazioni values(91,30,91);
insert into Partecipazioni values(92,34,92);
insert into Partecipazioni values(93,22,93);
insert into Partecipazioni values(94,6,94);
insert into Partecipazioni values(95,22,95);
insert into Partecipazioni values(96,28,96);
insert into Partecipazioni values(97,40,97);
insert into Partecipazioni values(98,4,98);
insert into Partecipazioni values(99,28,99);
insert into Partecipazioni values(100,28,100);
insert into Partecipazioni values(101,2,101);
insert into Partecipazioni values(102,22,102);
insert into Partecipazioni values(103,10,103);
insert into Partecipazioni values(104,20,104);
insert into Partecipazioni values(105,20,105);
insert into Partecipazioni values(106,6,106);
insert into Partecipazioni values(107,10,107);
insert into Partecipazioni values(108,6,108);
insert into Partecipazioni values(109,6,109);
insert into Partecipazioni values(110,18,110);
insert into Partecipazioni values(111,40,111);
insert into Partecipazioni values(112,2,112);
insert into Partecipazioni values(113,12,113);
insert into Partecipazioni values(114,10,114);
insert into Partecipazioni values(115,16,115);
insert into Partecipazioni values(116,12,116);
insert into Partecipazioni values(117,8,117);
insert into Partecipazioni values(118,4,118);
insert into Partecipazioni values(119,16,119);
insert into Partecipazioni values(120,6,120);
insert into Partecipazioni values(122,26,122);
insert into Partecipazioni values(123,36,123);
insert into Partecipazioni values(124,40,124);
insert into Partecipazioni values(125,2,125);
insert into Partecipazioni values(126,18,126);
insert into Partecipazioni values(127,32,127);
insert into Partecipazioni values(128,20,128);
insert into Partecipazioni values(129,16,129);
insert into Partecipazioni values(130,4,130);
insert into Partecipazioni values(131,6,131);
insert into Partecipazioni values(132,32,132);
insert into Partecipazioni values(133,24,133);
insert into Partecipazioni values(134,20,134);
insert into Partecipazioni values(135,32,135);
insert into Partecipazioni values(136,20,136);
insert into Partecipazioni values(137,12,137);
insert into Partecipazioni values(138,24,138);
insert into Partecipazioni values(139,14,139);
insert into Partecipazioni values(140,16,140);
insert into Partecipazioni values(141,16,141);
insert into Partecipazioni values(142,6,142);
insert into Partecipazioni values(143,4,143);
insert into Partecipazioni values(144,22,144);
insert into Partecipazioni values(145,20,145);
insert into Partecipazioni values(146,16,146);
insert into Partecipazioni values(147,12,147);
insert into Partecipazioni values(148,18,148);
insert into Partecipazioni values(149,32,149);
insert into Partecipazioni values(150,32,150);
insert into Partecipazioni values(151,18,151);
insert into Partecipazioni values(152,38,152);
insert into Partecipazioni values(153,16,153);
insert into Partecipazioni values(155,40,155);
insert into Partecipazioni values(157,2,157);
insert into Partecipazioni values(161,14,161);
insert into Partecipazioni values(162,2,162);
insert into Partecipazioni values(163,22,163);
insert into Partecipazioni values(164,2,164);
insert into Partecipazioni values(165,18,165);
insert into Partecipazioni values(166,20,166);
insert into Partecipazioni values(167,12,167);
insert into Partecipazioni values(168,30,168);
insert into Partecipazioni values(1,38,1);
insert into Partecipazioni values(2,8,2);
insert into Partecipazioni values(3,8,3);
insert into Partecipazioni values(4,4,4);
insert into Partecipazioni values(5,2,5);
insert into Partecipazioni values(8,36,8);
insert into Partecipazioni values(9,22,9);
insert into Partecipazioni values(11,40,11);
insert into Partecipazioni values(12,30,12);
insert into Partecipazioni values(13,34,13);
insert into Partecipazioni values(14,22,14);
insert into Partecipazioni values(15,14,15);
insert into Partecipazioni values(17,32,17);
insert into Partecipazioni values(18,20,18);
insert into Partecipazioni values(20,8,20);
insert into Partecipazioni values(21,20,21);
insert into Partecipazioni values(22,10,22);
insert into Partecipazioni values(24,30,24);
insert into Partecipazioni values(25,14,25);
insert into Partecipazioni values(26,36,26);
insert into Partecipazioni values(27,24,27);
insert into Partecipazioni values(28,38,28);
insert into Partecipazioni values(29,14,29);
insert into Partecipazioni values(30,4,30);
insert into Partecipazioni values(31,30,31);
insert into Partecipazioni values(32,4,32);
insert into Partecipazioni values(33,38,33);
insert into Partecipazioni values(34,32,34);
insert into Partecipazioni values(35,36,35);
insert into Partecipazioni values(36,2,36);
insert into Partecipazioni values(37,38,37);
insert into Partecipazioni values(38,26,38);
insert into Partecipazioni values(39,24,39);
insert into Partecipazioni values(40,10,40);
insert into Partecipazioni values(41,8,41);
insert into Partecipazioni values(42,40,42);
insert into Partecipazioni values(44,34,44);
insert into Partecipazioni values(45,36,45);
insert into Partecipazioni values(46,34,46);
insert into Partecipazioni values(47,30,47);
insert into Partecipazioni values(48,28,48);
insert into Partecipazioni values(49,12,49);
insert into Partecipazioni values(50,6,50);
insert into Partecipazioni values(51,40,51);
insert into Partecipazioni values(52,24,52);
insert into Partecipazioni values(53,6,53);
insert into Partecipazioni values(54,12,54);
insert into Partecipazioni values(55,38,55);
insert into Partecipazioni values(56,2,56);
insert into Partecipazioni values(57,34,57);
insert into Partecipazioni values(58,20,58);
insert into Partecipazioni values(59,10,59);
insert into Partecipazioni values(60,2,60);
insert into Partecipazioni values(61,26,61);
insert into Partecipazioni values(62,16,62);
insert into Partecipazioni values(63,28,63);
insert into Partecipazioni values(64,14,64);
insert into Partecipazioni values(66,2,66);
insert into Partecipazioni values(67,18,67);
insert into Partecipazioni values(68,30,68);
insert into Partecipazioni values(69,38,69);
insert into Partecipazioni values(70,4,70);
insert into Partecipazioni values(72,6,72);
insert into Partecipazioni values(73,2,73);
insert into Partecipazioni values(74,16,74);
insert into Partecipazioni values(75,20,75);
insert into Partecipazioni values(76,12,76);
insert into Partecipazioni values(78,26,78);
insert into Partecipazioni values(79,16,79);
insert into Partecipazioni values(80,28,80);
insert into Partecipazioni values(81,4,81);
insert into Partecipazioni values(82,10,82);
insert into Partecipazioni values(83,28,83);
insert into Partecipazioni values(84,2,84);
insert into Partecipazioni values(85,12,85);
insert into Partecipazioni values(86,2,86);
insert into Partecipazioni values(87,12,87);
insert into Partecipazioni values(88,8,88);
insert into Partecipazioni values(89,16,89);
insert into Partecipazioni values(90,32,90);
insert into Partecipazioni values(91,26,91);
insert into Partecipazioni values(93,24,93);
insert into Partecipazioni values(94,22,94);
insert into Partecipazioni values(95,36,95);
insert into Partecipazioni values(96,26,96);
insert into Partecipazioni values(97,24,97);
insert into Partecipazioni values(98,10,98);
insert into Partecipazioni values(99,24,99);
insert into Partecipazioni values(101,14,101);
insert into Partecipazioni values(102,14,102);
insert into Partecipazioni values(103,2,103);
insert into Partecipazioni values(105,24,105);
insert into Partecipazioni values(106,20,106);
insert into Partecipazioni values(107,30,107);
insert into Partecipazioni values(108,12,108);
insert into Partecipazioni values(109,20,109);
insert into Partecipazioni values(110,10,110);
insert into Partecipazioni values(112,36,112);
insert into Partecipazioni values(114,16,114);
insert into Partecipazioni values(115,10,115);
insert into Partecipazioni values(116,34,116);
insert into Partecipazioni values(117,38,117);
insert into Partecipazioni values(118,28,118);
insert into Partecipazioni values(119,28,119);
insert into Partecipazioni values(120,40,120);
insert into Partecipazioni values(121,22,121);
insert into Partecipazioni values(122,12,122);
insert into Partecipazioni values(123,18,123);
insert into Partecipazioni values(124,38,124);
insert into Partecipazioni values(125,24,125);
insert into Partecipazioni values(126,10,126);
insert into Partecipazioni values(127,4,127);
insert into Partecipazioni values(128,10,128);
insert into Partecipazioni values(129,28,129);
insert into Partecipazioni values(130,10,130);
insert into Partecipazioni values(131,34,131);
insert into Partecipazioni values(132,20,132);
insert into Partecipazioni values(133,36,133);
insert into Partecipazioni values(134,16,134);
insert into Partecipazioni values(135,18,135);
insert into Partecipazioni values(136,24,136);
insert into Partecipazioni values(138,8,138);
insert into Partecipazioni values(139,28,139);
insert into Partecipazioni values(140,36,140);
insert into Partecipazioni values(141,30,141);
insert into Partecipazioni values(142,14,142);
insert into Partecipazioni values(143,2,143);
insert into Partecipazioni values(144,12,144);
insert into Partecipazioni values(145,6,145);
insert into Partecipazioni values(146,18,146);
insert into Partecipazioni values(147,22,147);
insert into Partecipazioni values(148,40,148);
insert into Partecipazioni values(149,28,149);
insert into Partecipazioni values(150,8,150);
insert into Partecipazioni values(151,40,151);
insert into Partecipazioni values(152,2,152);
insert into Partecipazioni values(153,10,153);
insert into Partecipazioni values(154,28,154);
insert into Partecipazioni values(155,22,155);
insert into Partecipazioni values(156,12,156);
insert into Partecipazioni values(157,18,157);
insert into Partecipazioni values(158,28,158);
insert into Partecipazioni values(159,38,159);
insert into Partecipazioni values(160,6,160);
insert into Partecipazioni values(161,22,161);
insert into Partecipazioni values(162,14,162);
insert into Partecipazioni values(163,32,163);
insert into Partecipazioni values(164,20,164);
insert into Partecipazioni values(165,32,165);
insert into Partecipazioni values(166,4,166);
insert into Partecipazioni values(167,4,167);
insert into Partecipazioni values(168,32,168);
insert into Partecipazioni values(169,4,169);


UPDATE STATISTICS;


UPDATE SYSINDEXES
	SET isClustered = 't'
	 WHERE idxName = 'P_Impiegati' ;

UPDATE SYSINDEXES
	SET isClustered = 't'
	 WHERE idxName = 'P_Dipartimenti' ;



UPDATE Partecipazioni
SET Impegno = 20
WHERE Impegno <= 20;

UPDATE Partecipazioni
SET Impegno = 50
WHERE Impegno <= 50 And Impegno > 20;

UPDATE Partecipazioni
SET Impegno = 80
WHERE Impegno < 100 And Impegno > 50;

UPDATE Partecipazioni
SET Impegno = 100
WHERE Impegno > 100;

